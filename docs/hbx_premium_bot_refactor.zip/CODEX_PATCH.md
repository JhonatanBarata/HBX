# Refatoração final: Conexão primeiro, Bot depois

## Regra de produto

- `/dashboard/whatsapp` é o começo do sistema.
- Ali o cliente escolhe `QRCODE` ou `META`.
- Ali gera QR, conecta, espera bootstrap e libera `BOT`.
- `/dashboard/vendas/automacao` não pergunta mais conexão.
- Se a pessoa chegou no BOT, ela já configurou a conexão.
- O BOT começa direto por fluxo: módulo → mensagem → opções → simulação → publicar.
- UI sem texto explicativo longo.
- Usar somente variáveis do tema.

## Arquivos novos

### WhatsApp onboarding

- `frontend/src/app/dashboard/whatsapp/_components/WhatsAppConnectionWizard.tsx`
- `frontend/src/app/dashboard/whatsapp/_components/WhatsAppConnectionWizard.module.css`

### Bot premium

- `frontend/src/app/dashboard/vendas/automacao/_components/BotAutomationPremiumEntry.tsx`
- `frontend/src/app/dashboard/vendas/automacao/_components/BotAutomationPremiumEntry.module.css`
- `frontend/src/app/dashboard/vendas/automacao/_components/BotGameBuilderModal.tsx`
- `frontend/src/app/dashboard/vendas/automacao/_components/BotGameBuilderModal.module.css`

## Encaixe em `/dashboard/whatsapp/page.client.tsx`

Adicionar import:

```tsx
import WhatsAppConnectionWizard from "./_components/WhatsAppConnectionWizard";
```

No `return`, dentro do bloco onde `payload` já existe, substituir a área principal por:

```tsx
<WhatsAppConnectionWizard
  payload={payload}
  modalPayload={modalPayload}
  loading={loading || modalLoading}
  saving={saving}
  modalSaving={modalSaving}
  qrBusy={qrBootstrapBusy}
  qrMessage={message}
  qrError={qrOperationalError}
  onChooseMode={(mode) => void chooseMode(mode)}
  onConnectQr={() => void runModalAction("connect")}
  onDisconnectQr={() => void runModalAction("disconnect")}
  onRequestMeta={() => void requestMigration("central_whatsapp")}
/>
```

## Encaixe em `/dashboard/vendas/automacao/page.client.tsx`

Adicionar import:

```tsx
import BotAutomationPremiumEntry from "./_components/BotAutomationPremiumEntry";
```

Substituir o `flowPanel` antigo:

```tsx
flowPanel={
  <BotSupremeFlowWorkspace ... />
}
```

por:

```tsx
flowPanel={
  <BotAutomationPremiumEntry
    botConfig={draftConfig}
    agendaConfig={agendaConfig}
    centerPayload={centerPayload}
    modalPayload={modalPayload}
    providerCapabilities={providerCapabilities}
    publishing={publishing}
    recoveryEnabled={recoveryEnabled}
    hasUnsavedChanges={hasUnsavedChanges}
    onConfigChange={setDraftConfig}
    onSave={(nextConfig) => void saveBotConfig(nextConfig, "Bot publicado.")}
  />
}
```

## Opcional recomendado

No `BotQrWorkspace.tsx`, trocar textos:

```tsx
{ id: "connection", label: "Conexao", helper: "QR e canal" },
{ id: "flow", label: "Fluxo do Bot", helper: "Menu Supremo" },
{ id: "publish", label: "Publicar", helper: "Checklist final" },
```

por:

```tsx
{ id: "connection", label: "Status", helper: "WhatsApp" },
{ id: "flow", label: "BOT", helper: "Fluxo" },
{ id: "publish", label: "OK", helper: "Publicar" },
```

E trocar a descrição do header para algo curto ou remover.

## Observação de tema

Não colocar cores fixas nos novos componentes. Usar:

- `--background`
- `--surface`
- `--surface-raised`
- `--foreground`
- `--foreground-soft`
- `--line`
- `--button-primary`
- `--button-accent`
- `--button-success`
- `--selection-accent`
- `--selection-accent-soft`
- `--shadow-*`
- `--radius-*`

## Critério de aceite

1. Primeira entrada: usuário vê `QRCODE` e `META`.
2. Clicar QRCODE mostra loading premium até QR aparecer.
3. QR conectado libera botão `BOT`.
4. Entrar no BOT não pergunta conexão.
5. BOT abre fluxo por etapas.
6. Nada de textos longos.
7. Transições em botões/cards/modais/loadings.
8. Cores sempre controladas pelo tema.
